class Arena
{
    constructor(w, h)
    {
        const matrix = [];		// viene creata una matrice in locale
        while (h--) {								// fin quando l'altezza non è 0, viene decrementata
            matrix.push(new Array(w).fill(0));		// quindi viene aggiunto un array di 0 di larghezza w (width)
        }
        this.matrix = matrix;			// viene restituita la matrice creata (vuota)
    }

    clear()
    {
        this.matrix.forEach(row => row.fill(0));
    }
	
    collide(player)		// funzione per verificare se le due matrici logiche hanno dei pezzi in sovrapposizione
    {
        const [m, o] = [player.matrix, player.pos];		// crea una costante contenenti la matrice del giocatore e l'offset del giocatore
        for (let y = 0; y < m.length; ++y) {
            for (let x = 0; x < m[y].length; ++x) {
                if (m[y][x] !== 0 &&						// se nella matrice del giocatore in posizione y,x è presente un pezzo (!== 0)
                    (this.matrix[y + o.y] &&				// e se nella matrice dell'arena in posizione y,x (tenendo conto dell'offset) è presente un pezzo (!== 0)
                    this.matrix[y + o.y][x + o.x]) !== 0) {
                    return true;					// restituisce true in caso positivo
                }
            }
        }
        return false;				// restituisce false in caso negativo
    }

    merge(player)			// questa funzione copia i valori presenti nell'array player in arena (campo di gioco)
    {
        player.matrix.forEach((row, y) => {
            row.forEach((value, x) => {
                if (value !== 0) {			// Se il valore non è 0, e quindi è presente un pezzo, allora questo viene copiato
                    this.matrix[y + player.pos.y][x + player.pos.x] = value;
                }
            });
        });
    }

    sweep()
    {
        let rowCount = 1;
        let score = 0;
        outer: for (let y = this.matrix.length - 1; y > 0; --y) {
            for (let x = 0; x < this.matrix[y].length; ++x) {
                if (this.matrix[y][x] === 0) {
                    continue outer;
                }
            }

            const row = this.matrix.splice(y, 1)[0].fill(0);
            this.matrix.unshift(row);
            ++y;

            score += rowCount * 10;
            rowCount *= 2;
        }
        return score;
    }
}
