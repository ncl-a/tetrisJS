function createPiece(type) {			// funzione che restituisce la matrice contenente il pezzo dato il suo ID
    if (type === 'T') {
        return [
            [0, 0, 0],
            [1, 1, 1],
            [0, 1, 0],
        ];
    } else if (type === 'O') {
        return [
            [2, 2],
            [2, 2],
        ];
    } else if (type === 'L') {
        return [
            [0, 3, 0],
            [0, 3, 0],
            [0, 3, 3],
        ];
    } else if (type === 'J') {
        return [
            [0, 4, 0],
            [0, 4, 0],
            [4, 4, 0],
        ];
    } else if (type === 'I') {
        return [
            [0, 5, 0, 0],
            [0, 5, 0, 0],
            [0, 5, 0, 0],
            [0, 5, 0, 0],
        ];
    } else if (type === 'S') {
        return [
            [0, 6, 6],
            [6, 6, 0],
            [0, 0, 0],
        ];
    } else if (type === 'Z') {
        return [
            [7, 7, 0],
            [0, 7, 7],
            [0, 0, 0],
        ];
    }
}

const tetri = [];

const playerElements = document.querySelectorAll('.player');
[...playerElements].forEach(element => {
    const tetris = new Tetris(element);
    tetri.push(tetris);
});

const keyListener = (event) => {				// In base al codice del tasto premuto, viene generata una mossa specifica
    [
        [65, 68, 81, 69, 83],
        [72, 75, 89, 73, 74],
    ].forEach((key, index) => {
        const player = tetri[index].player;
        if (event.type === 'keydown') {
            if (event.keyCode === key[0]) {						// spostamento del pezzo a sinistra (al premere di A)
                player.move(-1);
            } else if (event.keyCode === key[1]) {				// spostamento del pezzo a destra (al premere di D)
                player.move(1);
            } else if (event.keyCode === key [2]) {				// ruota pezzi a sinistra (al premere di Q)
                player.rotate(-1); 
            } else if (event.keyCode === key[3]) {				// ruota pezzi a destra (al premere di E)
                player.rotate(1);				
            }
        }

        if (event.keyCode === key[4]) {							// quando si preme S avviene la discesa veloce
            if (event.type === 'keydown') {
                if (player.dropInterval !== player.DROP_FAST) {
                    player.drop();
                    player.dropInterval = player.DROP_FAST;
                }
            } else {
                player.dropInterval = player.DROP_SLOW;
            }
        }
    });
};

document.addEventListener('keydown', keyListener);				// Quando viene premuto un tasto viene richiamata la funzione keyListener
document.addEventListener('keyup', keyListener);				// Quando viene rilasciato il tasto la mossa viene interrotta


var ctrl = setInterval(function() {             // in caso il gioco finisca, compare un popup

    if(!tetri[0].player.getFinish() || !tetri[1].player.getFinish())        // se uno dei due giocatori perde:
    {
        clearInterval(ctrl);                // ferma il controllo (setInterval)
        
        document.getElementById("p").innerHTML = !tetri[0].player.getFinish() ? "<span style=\"color:rgb(97, 62, 143);\">Player Right</span>" : "<span style=\"color:rgb(97, 62, 143);\">Player Left</span>";
        
        tetri[0].player.setFinishFalse();           // imposta false la creazione di nuovi pezzi
        tetri[1].player.setFinishFalse();
        document.getElementById("btnWin").click();      // fa comparire il popup
        tetri[0].player.matrix.forEach(row => row.fill(0));         // azzera la matrice giocatore così da far scomparire i pezzi in discesa
        tetri[1].player.matrix.forEach(row => row.fill(0));
    }
        

}, 500);