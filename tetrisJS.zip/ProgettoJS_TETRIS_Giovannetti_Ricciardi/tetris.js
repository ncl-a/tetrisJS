class Tetris
{
    constructor(element)
    {
        this.element = element;
        this.canvas = element.querySelector('canvas');		// linka il pezzo canvas (sfondo) del .html
        this.context = this.canvas.getContext('2d');		// il canvas conterrà elementi 2d 
        this.context.scale(20, 20);							// scala di ingrandimento pezzo x: 1:20 y: 1:20 (pixel)

        this.arena = new Arena(12, 20);
        this.player = new Player(this);

        this.colors = [
            null,
            '#FF0D72',
            '#0DC2FF',
            '#0DFF72',
            '#F538FF',
            '#FF8E0D',
            '#FFE138',
            '#3877FF',
        ];

        let lastTime = 0;					// Quando viene generato il pezzo siamo al tempo 0 e non ci sono istanti precedenti ad esso 
        const update = (time = 0) => {
            const deltaTime = time - lastTime;		// Permette di calcolare il tempo trascorso
            lastTime = time;						// Viene aggirnata la variabile lastTime al nuovo time

            this.player.update(deltaTime);

            this.draw();	// stampa il pezzo, in questa posizione permette di non stampare lo stesso pezzo più volte durante il suo spostamento
            requestAnimationFrame(update);		// effettua l'animazione prima che venga elaborata la pagina
        };
        update();

        this.updateScore(0);
    }

    draw()
    {
        this.context.fillStyle = '#000';		// imposta il colore di riempimento dello sfondo su nero
        this.context.fillRect(0, 0, this.canvas.width, this.canvas.height);		// crea lo sfondo da posizione 0,0 su piano cartesiano a canvas.width e canvas.height

        this.drawMatrix(this.arena.matrix, {x: 0, y: 0});		// Stampa la matrice arena a partire dal punto di coordinate 0, 0
        this.drawMatrix(this.player.matrix, this.player.pos);	// Stampa il pezzo in movimento del giocatore nella sua posizione attuale
    }

    drawMatrix(matrix, offset)
    {
        matrix.forEach((row, y) => {
            row.forEach((value, x) => {
                if (value !== 0) {
                    this.context.fillStyle = this.colors[value];		// imposta il colore di riempimento in base all'ID del pezzo 
                    this.context.fillRect(x + offset.x,					// riempimento tenendo conto dell'offset (offset = tiene conto dello spostamento dato dall'utente)
                                     y + offset.y,
                                     1, 1);
                }
            });
        });
    }

    updateScore(score)		// aggiorna i punti
    {
        //this.element.querySelector('.score').innerText = score;
    }
}