class Player
{
    constructor(tetris)
    {
        this.DROP_SLOW = 1000;
        this.DROP_FAST = 50;

        this.tetris = tetris;
        this.arena = tetris.arena;

        this.dropCounter = 0;
        this.dropInterval = this.DROP_SLOW;

        this.pos = {x: 0, y: 0};		// offset del pezzo, inizialmente a 0 0
        this.matrix = null;				// ID pezzo generato dalla classe Player (utente), inizialmente null
        //this.score = 0;

        this.finish = true;             // true = il tetris prosegue, false = fino gioco

        this.reset();
    }

    drop()
    {
        this.pos.y++;
        if (this.arena.collide(this)) {			// Se il pezzo tocca un altro pezzo o il fondo del campo
            this.pos.y--;						// viene riposizionato correttamente 
            this.arena.merge(this);				// viene sovrapposta la matrice del nuovo pezzo a quella di arena
            this.reset();
            this.score += this.arena.sweep();
            this.tetris.updateScore(this.score);
        }
        this.dropCounter = 0;
    }

    move(dir)					// funzione che effettua lo spostamento del pezzo nella matrice
    {
        this.pos.x += dir;						// effettua lo spostamento del pezzo nella matrice
        if (this.arena.collide(this)) {
            this.pos.x -= dir;					// nel caso in cui il pezzo esca dalla matrice viene annullata la mossa 
        }
    }

    reset()
    {
        const pieces = 'ILJOTSZ';					// array di pezzi che possono essere generati

        if(this.finish)
        {
            this.matrix = createPiece(pieces[pieces.length * Math.random() | 0]);			// viene generato un pezzo casuale dalla matrice dei pezzi
            this.pos.y = 0;																	// il pezzo viene generato in alto e dunque ha y = 0
            this.pos.x = (this.arena.matrix[0].length / 2 | 0) -							// viene calcolata la posizione del pezzo nella matrice affinchè sia centrato						
                        (this.matrix[0].length / 2 | 0);									// per centrare il pezzo viene controllata la sua larghezza ( |0 serve per troncare)
        }

        if (this.arena.collide(this)) {								// questo comando permette di controllare quando il campo di gioco è saturo il gioco si deve fermare
            console.log("fine");
            
            this.finish = false;
            this.arena.clear();										
            this.score = 0;
            updateScore();
        }
    }

    rotate(dir)				
    {
        const pos = this.pos.x;
        let offset = 1;									// l'offset permette di ruotare un pezzo senza che questo collida
        this._rotateMatrix(this.matrix, dir);			// viene ruotata la matrice
        while (this.arena.collide(this)) {				// durante la collisione
            this.pos.x += offset;						// viene sommato l'offset per permettere la rotazione
            offset = -(offset + (offset > 0 ? 1 : -1));	// nel caso in cui l'offset sia maggiore di 0, viene restituito 1, in caso contrario -1
            if (offset > this.matrix[0].length) {
                this._rotateMatrix(this.matrix, -dir);	// nel caso in cui la collisione si trovi a destra l'offset deve essere negativo (situazione inversa a sinistra)
                this.pos.x = pos;						// restituisce l'offset originale
                return;
            }
        }
    }

    _rotateMatrix(matrix, dir)	// per ruotare un pezzo è necessario effettuare prima la matrice trasposta e poi l'inversa (matrice player)
    {
        for (let y = 0; y < matrix.length; ++y) {
            for (let x = 0; x < y; ++x) {			// matrice trasposta
                [
                    matrix[x][y],
                    matrix[y][x],
                ] = [
                    matrix[y][x],
                    matrix[x][y],
                ];
            }
        }

        if (dir > 0) {								// matrice inversa
            matrix.forEach(row => row.reverse());
        } else {
            matrix.reverse();
        }
    }

    update(deltaTime)
    {
        this.dropCounter += deltaTime;
        if (this.dropCounter > this.dropInterval) {
            this.drop();
        }
    }

    getFinish()   
    {
        return this.finish;

    }

    setFinishFalse()            
    {
        this.finish = false;

    }

}
